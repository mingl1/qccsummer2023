from django.apps import AppConfig


class DolistConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dolist'
